function [G,varRatio, costVec, numIter] = FiedlerConstruct(fea,samplePerc,chosenPercEachIter,sig,maxIter,k,AddEdge,tol)
varRatio=[];
costVec=[];
tic
%create the matrix based on kNN graph
fname='kNN.mtx';% Initial kNN graph before GRASPEL iterations
[G,A]=getMatrixKNN(fea,k,30,fname); %original kNN
tic
i=0;
if AddEdge==1
% Iteratively adding new edges and checking convergence
    for i=1:maxIter 
           [G,var,cost] = FiedAddEdges(G,fea,samplePerc,chosenPercEachIter,sig,tol);
%          [G,var,cost] = FiedAddEdgesMulti(G,fea,samplePerc,chosenPercEachIter,sig,tol);

        if i==1
            cost0=cost;
        end
        varRatioPre=varRatio;
        varRatio=[varRatio;var];  
        costVec=[costVec;cost];
         if var <tol 
                break;
         end 
    end
end
toc
numIter=i;

    
 
